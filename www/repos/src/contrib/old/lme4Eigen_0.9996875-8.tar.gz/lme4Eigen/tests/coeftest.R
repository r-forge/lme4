library(lme4a)
library(coefplot2)

fm1 <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
coeftab(fm1)
