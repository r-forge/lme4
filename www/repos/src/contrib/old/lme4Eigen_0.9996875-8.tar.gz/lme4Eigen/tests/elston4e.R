tickdata = read.table("Elston2001_tickdata.txt",header=TRUE,
  colClasses=c("factor","numeric","factor","numeric","factor","factor"))

tickdata <- transform(tickdata,cHEIGHT=scale(HEIGHT,scale=FALSE))

library(lme4Eigen)
ste1 <- system.time(mod1_glmer4e <- glmer(TICKS~1+(1|BROOD)+(1|INDEX),
                    family="poisson",data=tickdata))
ste2 <- system.time(mod2_glmer4e <- update(mod1_glmer4e,.~.+YEAR))
ste3 <- system.time(mod3_glmer4e <- update(mod1_glmer4e,.~.+HEIGHT))
ste4 <- system.time(mod4_glmer4e <- update(mod2_glmer4e,.~.+HEIGHT))
ste5 <- system.time(mod5_glmer4e <- update(mod2_glmer4e,.~.+(1|LOCATION)))
ste6 <- system.time(mod6_glmer4e <- update(mod5_glmer4e,.~.+HEIGHT,verbose=2L))

ste6
mod6_glmer4e
