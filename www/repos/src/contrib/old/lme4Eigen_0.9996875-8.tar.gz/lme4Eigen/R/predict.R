
##' @param newdata data frame for which to evaluate predictions
##' @param REform formula for random effects to include.  If NULL, include all random effects; if NA, include no random effects
##' @note explain why there is no option for computing standard errors of predictions!

## FIXME: separate predict functions for lmer/glmer/nlmer?
##   add type=c("link","response") if appropriate

predict.merMod <- function(object, newdata=NULL, REform=NULL,
                           terms=NULL, ...) {

  if (!is.null(terms)) stop("terms functionality for predict not yet implemented")
  X_orig <- getME(object, "X")
  if (is.null(newdata) && is.null(REform)) {
    pred <- fitted(object)
  } else {
    if (is.null(newdata)) {
      X <- X_orig
    } else {
      ## FIXME/WARNING: how do we do this in an eval-safe way???
      form <- object@call$formula
      form[[3]] <- if(is.null(nb <- nobars(form[[3]]))) 1 else nb
      RHS <- form[-2]
      X <- model.matrix(RHS, newdata, contrasts=attr(X_orig,"contrasts"))
    }
    if (is.null(REform)) {
    }
  }

  mkReTrms(findbars(REform[[3]],newdata))
  ## transform according to preferred scale
}
  
    
