library(lme4)

set.seed(101)
Y <- matrix(rnorm(200),nrow=100)
x <- rnorm(100)
f <- factor(rep(LETTERS[1:2],each=50))
d <- data.frame(Y=I(Y),x,f)

## by hand:
d1 <- with(d,data.frame(y=Y[,1],x,f))
m1 <- lmer(y~x+(1|f),data=d1)
mlist <- apply(d$Y[,-1,drop=FALSE],2,refit,object=m1)
res <- c(list(m1),mlist)

m2 <- lm(Y~x+f,data=d)
##
## > methods(class="mlm")
##  [1] add1.mlm*         anova.mlm         deviance.mlm*     drop1.mlm*       
##  [5] estVar.mlm*       mauchly.test.mlm* plot.mlm          predict.mlm      
##  [9] SSD.mlm*          summary.mlm       vcov.mlm*        

lmer(Y~x+(1|f),data=d)
