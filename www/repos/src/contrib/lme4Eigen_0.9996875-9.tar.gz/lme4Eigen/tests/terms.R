library(lme4Eigen)
fm1 <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
