library(lme4Eigen)
library(MASS)

## unstructured data.  glm does fine in a crude loop with negative.binomial()
set.seed(101)
d <- data.frame(z=rnbinom(1000,mu=1,size=0.5))
tmpf0 <- function(logth) { -2*c(logLik(glm(z~1,
                                           data=d,family=negative.binomial(theta=exp(logth))))) }
logthvec <- seq(-2,2,by=0.1)
dvec0 <- sapply(logthvec,tmpf0)
plot(logthvec,dvec0)

## structured data, best-case scenario.
set.seed(102)
d1 <- data.frame(x=runif(1000),f=rep(LETTERS[1:25],each=40))
u_f <- rnorm(25,sd=1)
d1 <- transform(d1,z=rnbinom(1000,mu=exp(1+2*x+u_f[f]),size=0.5))

g0 <- glmer(z~x+(1|f),family=poisson,data=d1)

## get initial estimate of theta ...
Y <- model.response(model.frame(g0))
mu <- fitted(g0)
w <- g0@resp$weights
control <- list(maxit=20,trace=0)
th <- theta.ml(Y, mu, sum(w), w, limit = control$maxit,
                     trace = control$trace > 2)

tmpf1A <- function(logtheta,g) {
  -2*c(logLik(update(g,family=negative.binomial(theta=exp(logtheta)))))
}
## fit from scratch -- something weird about update()?
tmpf1B <- function(logtheta) {
  -2*c(logLik(glmer(z~x+(1|f),data=d1,family=negative.binomial(theta=exp(logtheta)))))
}

tmpf1A(log(th),g0)
tmpf1B(log(th))
dvec1A <- sapply(logthvec,tmpf1A,g=g0)
dvec1B <- sapply(logthvec,tmpf1B)
all.equal(dvec1A,dvec1B)

plot(logthvec,dvec1A)

## try fitting as fixed effect
tmpf2 <- function(logth) { -2*c(logLik(glm(z~x+f,
                                           data=d1,family=negative.binomial(theta=exp(logth))))) }
dvec2 <- sapply(logthvec,tmpf2)
plot(logthvec,dvec2)

###############3
data(Owls,package="glmmADMB")
glmer.nb <- function(formula, data, family = gaussian, sparseX = FALSE,
                     control = list(), start = NULL, verbose = 0L,
                     nAGQ = 1L, subset, weights, na.action,
                     offset, contrasts = NULL, mustart, etastart,
                     tolPwrss = 1e-10,
                     optimizer = c("NelderMead", "bobyqa"),
                     init.theta, link=log, ...) {
  link <- substitute(link)
  fam0 <- if (missing(init.theta)) {
    do.call("poisson", list(link=link))
  } else {
    do.call("negative.binomial", list(theta = init.theta, 
                                      link = link))
  }
  dots <- list(...)
  mf <- Call <- match.call()
  mf[[1]] <- as.name("glmer")
  mf$family <- fam0
  control <- list(maxit=20,trace=0)
  g0 <- eval(mf,parent.frame())
  Y <- model.response(g0@frame,"numeric")
  mu <- fitted(g0)
  w <- g0@resp$weights
  th <- MASS::theta.ml(Y, mu, sum(w), w, limit = control$maxit,
                       trace = control$trace > 2)
  ## need trickery with call?  can't update because eval evaluates in
  ## wrong frame ...
  g0@call$offset <- eval(g0@call$offset)
  tmpf <- function(logtheta) {
    -2*logLik(update(g0,family=negative.binomial(theta=exp(logtheta))))
  }
  tmpf(log(th))
  opt <- optim(fn=tmpf,par=log(th))
  
}

library(MASS) ## for theta.ml, negative.binomial
g0 <- glmer(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls,family="poisson")
Y <- model.response(model.frame(g0))
mu <- fitted(g0)
w <- g0@resp$weights
control <- list(maxit=20,trace=0)
th <- theta.ml(Y, mu, sum(w), w, limit = control$maxit,
                     trace = control$trace > 2)
tmpf <- function(logtheta) {
  -2*c(logLik(update(g0,family=negative.binomial(theta=exp(logtheta)))))
}
tmpf3 <- function(logtheta) {
  g <- glmer(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls,family=negative.binomial(theta=exp(logtheta)))
  -2*c(logLik(g))
}

tmpf(log(th))
tmpf3(log(th))
thvec <- seq(-5,3,by=0.5)
dvec <- sapply(thvec,tmpf)
dvec3 <- sapply(thvec,tmpf3)
plot(thvec,dvec)
lines(thvec,dvec3)

g2 <- glmer(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls,family=negative.binomial(theta=0.84))
-2*c(logLik(g2))

g3 <- glmer(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls,family=negative.binomial(theta=0.1))
-2*c(logLik(g3))

glmmPQL(SiblingNegotiation~FoodTreatment*SexParent,
        random=~1|Nest,
        offset=logBroodSize,
        data=Owls,family=poisson)
## family=negative.binomial(theta=0.1))
## ???

library(glmmADMB)
g3 <- glmmadmb(SiblingNegotiation~FoodTreatment*SexParent+
               (1|Nest)+offset(log(BroodSize)),family="nbinom",
               data=Owls)


g0 <- glmer.nb(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls)
Y <- model.response(model.frame(g0))
mu <- fitted(g0)
w <- g0@resp$weights
control <- list(maxit=20,trace=0)
th <- theta.ml(Y, mu, sum(w), w, limit = control$maxit,
                     trace = control$trace > 2)



  dots <- list(...)
  mf <- Call <- match.call()
  m <- match(c("formula", "data", "subset", "weights", "na.action", 
        "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  mf[[1L]] <- as.name("model.frame")
  mf <- eval.parent(mf)
  Terms <- attr(mf, "terms")
  if (method == "model.frame") 
    return(mf)
  Y <- model.response(mf, "numeric")
  X <- if (!is.empty.model(Terms)) {
    model.matrix(Terms, mf, contrasts)
  } else matrix(, NROW(Y), 0)
  w <- model.weights(mf)
  if (!length(w)) {
    w <- rep(1, nrow(mf))
  } else if (any(w < 0)) 
    stop("negative weights not allowed")
  offset <- model.offset(mf)

              th <- theta.ml(Y, mu, sum(w), w, limit = control$maxit, 
            trace = control$trace > 2)

        MASS::theta.ml(y, mu, n, weights, limit = 10, eps = .Machine$double.eps^0.25,
              trace = FALSE)
  mf <- Call <- match.call()
  m <- match(c("formula", "data", "subset", "weights", "na.action", 
               "etastart", "mustart", "offset"), names(mf), 0)


g0 <- glmer(SiblingNegotiation~FoodTreatment*SexParent+
            (1|Nest)+offset(log(BroodSize)),
            data=Owls,
            family=negative.binomial(theta=1))
g1 <- update(g0,family=negative.binomial(theta=1.1))
g2 <- update(g0,family=negative.binomial(theta=1.2))
