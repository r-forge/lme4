library(lme4Eigen)
library(ggplot2)
do_plots <- FALSE

fn <- "elston_fits.RData"
if (!file.exists(fn)) {
  tvec <- seq(-13,-7,by=0.1)
  dmat <- matrix(nrow=length(tvec),ncol=10,  
                 dimnames=list(NULL,c("logtol","deviance","time_elapsed",
                   paste("theta",1:3,sep=""),paste("beta",1:4,sep=""))))
  for (i in seq_along(tvec)) {
    tt <- system.time(gg <- glmer(form,family="poisson",data=grouseticks,tolPwrss=10^tvec[i]))["elapsed"]
    cat(i,tvec[i],deviance(gg),"\n")
    dmat[i,] <- c(tvec[i],deviance(gg),tt,allcoefs(gg))
  }
  dmat <- as.data.frame(dmat)
  save("dmat",file=fn)
} else load(fn)

if (do_plots) {
  newdev <- apply(dmat[,-(1:3)],1,mm)
  newdev2 <- apply(dmat[,-(1:3)],1,mm2)
  all.equal(newdev,newdev2)
  library(ggplot2)
  library(reshape)
  qplot(logtol,value,data=melt(dmat,id.var="logtol"),geom=c("line"))+
    facet_wrap(~variable,scale="free")+
      geom_line(data=data.frame(logtol=dmat$logtol,value=newdev,variable="deviance"),
                colour="blue")+
                  geom_hline(data=data.frame(variable="deviance",val=mm(allcoefs1)),
                             aes(yintercept=val),colour="red")+theme_bw()+
                               geom_vline(data=data.frame(variable="deviance",val=-10),
                                          aes(xintercept=val),colour="gray")
  ggsave(file="elston_tolPwrss.pdf")
}
