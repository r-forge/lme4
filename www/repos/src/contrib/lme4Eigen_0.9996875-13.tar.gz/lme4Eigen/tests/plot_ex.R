## pkg <- "nlme"  ## or lme4Eigen
pkg <- "lme4Eigen"
do_plot <- FALSE

data(Orthodont,package="nlme")

library(pkg, character.only=TRUE)
if (pkg=="lme4Eigen") {
  ## source("~/R/pkgs/lme4/pkg/lme4Eigen/R/plot.R")
  fm1 <- lmer(distance ~ age+ (age|Subject), Orthodont)
} else {
  fm1 <- lme(distance ~ age,
             random=~age|Subject, Orthodont)
}
## standardized residuals versus fitted values by gender
(p1 <- plot(fm1, resid(., type = "pearson") ~ fitted(.) | Sex, abline = 0))
## FIXME: resid currently takes "partial" or "pearson", which means that
##   partial matching on "p" doesn't work
## box-plots of residuals by Subject
(p2 <- plot(fm1, Subject ~ resid(.)))
## observed versus fitted values by Subject
(p3 <- plot(fm1, distance ~ fitted(.) | Subject, abline = c(0,1)))
## looks better with smaller points on my screen
(p4 <- plot(fm1, distance ~ fitted(.) | Subject, abline = c(0,1),cex=0.5))

if (do_plot) {
  pdf(paste("plot_ex_",pkg,".pdf",sep=""))
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  dev.off()
}

## ggplot2
## qplot(.fitted,.resid,data=fm1,colour=Sex)
