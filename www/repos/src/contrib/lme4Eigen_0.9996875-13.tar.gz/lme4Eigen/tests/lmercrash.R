library(lme4Eigen)

for (i in 1:20) {
  cat("**",i,"\n")
  cat("base fit\n")
  fm1 <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
  cat("update\n")
  fm1U <- update(fm1,.~.-Days)
}

