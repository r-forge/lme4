library(lme4Eigen)

for (i in 1:10) {
  cat("**",i,"\n")
  cat("base fit\n")
  gm1 <- glmer(cbind(incidence, size - incidence) ~ period + (1 | herd),
                   data = cbpp, family = binomial)
  cat("update\n")
  gm1U <- update(gm1,.~.-period)
}

