library(lme4Eigen)
library(MASS)

## unstructured data.  glm does fine in a crude loop with negative.binomial()
set.seed(101)
d <- data.frame(z=rnbinom(1000,mu=1,size=0.5))
tmpf0 <- function(logth) { -2*c(logLik(glm(z~1,
                                           data=d,family=negative.binomial(theta=exp(logth))))) }
logthvec <- seq(-2,2,by=0.1)
dvec0 <- sapply(logthvec,tmpf0)
plot(logthvec,dvec0)

## structured data, best-case scenario.
set.seed(102)
d1 <- data.frame(x=runif(1000),f=rep(LETTERS[1:25],each=40))
u_f <- rnorm(25,sd=1)
d1 <- transform(d1,z=rnbinom(1000,mu=exp(1+2*x+u_f[f]),size=0.5))

g0 <- glmer(z~x+(1|f),family=poisson,data=d1)

## get initial estimate of theta ...
Y <- model.response(model.frame(g0))
mu <- fitted(g0)
w <- g0@resp$weights
control <- list(maxit=20,trace=0)
th <- theta.ml(Y, mu, sum(w), w, limit = control$maxit,
                     trace = control$trace > 2)

tmpf1A <- function(logtheta,g) {
  -2*c(logLik(update(g,family=negative.binomial(theta=exp(logtheta)))))
}
## fit from scratch -- something weird about update()?
tmpf1B <- function(logtheta) {
  -2*c(logLik(glmer(z~x+(1|f),data=d1,family=negative.binomial(theta=exp(logtheta)))))
}

tmpf1A(log(th),g0)
tmpf1B(log(th))
dvec1A <- sapply(logthvec,tmpf1A,g=g0)
dvec1B <- sapply(logthvec,tmpf1B)
all.equal(dvec1A,dvec1B)

plot(logthvec,dvec1A)

## try fitting as fixed effect
tmpf2 <- function(logth) { -2*c(logLik(glm(z~x+f,
                                           data=d1,family=negative.binomial(theta=exp(logth))))) }
dvec2 <- sapply(logthvec,tmpf2)
plot(logthvec,dvec2)
