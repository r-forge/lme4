library(lme4Eigen)
gm1 <- glmer(cbind(incidence, size - incidence) ~ period + (1 | herd),
             data = cbpp, family = binomial, verbose=0)

gm2 <- update(gm1,verbose=1)
gm2 <- update(gm1,verbose=2)
gm3 <- update(gm1,verbose=3)
