library(lme4Eigen)
## library(MASS)

set.seed(102)
d1 <- data.frame(x=runif(1000),f=rep(LETTERS[1:25],each=40))
u_f <- rnorm(25,sd=1)
## d1 <- transform(d1,z=rnbinom(1000,mu=exp(1+2*x+u_f[f]),size=0.5))
d1 <- transform(d1,z=rpois(1000,lambda=exp(1+2*x+u_f[f])))

#logtheta <- 0
for (i in 1:10) {
  cat("**",i,"\n")
  cat("fit Poisson \n")
  g0 <- glmer(z~x+(1|f),family=poisson,data=d1)
  cat("update\n")
  ## g1 <- update(g0,family=negative.binomial(theta=exp(logtheta)))
  g1 <- update(g0,.~.-x) 
  ## g1 <- update(g0,family=gaussian,data=d1)
  ## g1 <- update(g0,family=Gamma,data=d1)
}

