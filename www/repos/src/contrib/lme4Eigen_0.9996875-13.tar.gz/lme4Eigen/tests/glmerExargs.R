library(lme4Eigen)
gm1 <- glmer(cbind(incidence, size - incidence) ~ period + (1 | herd),
             data = cbpp, family = binomial,
             REML=TRUE,junk=FALSE)
