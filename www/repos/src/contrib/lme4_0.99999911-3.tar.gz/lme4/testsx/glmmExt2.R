load("gammaErr.RData")
library("lme4")
gm2 <- glmer(y ~ 1 + (1|block), d, Gamma, nAGQ=0)
gm2B <- glmer(y ~ 1 + (1|block), d, Gamma)
try(gm2B <- glmer(y ~ 1 + (1|block), d, Gamma))
v <- unlist(getME(gm2,c("theta","beta")))
dfm2 <- glmer(y ~ 1 + (1|block), d, Gamma, verbose = 50,
              devFunOnly=TRUE, nAGQ=1)
get("pp",environment(dfm2))$delu
get("pp",environment(dfm2))$delb  ## 5.463693
get("pp",environment(dfm2))$beta0 ## 0
pp <- environment(dfm2)$pp$copy(shallow=FALSE)
## $delb has been set to zero here!
pp$delb ## zero!!
pp$delu ## zero !!
dfm2(v)
pp2 <- get("pp",environment(dfm2))
ls(get("pp",environment(dfm2)))
get("pp",environment(dfm2))$delu  ## unchanged
get("pp",environment(dfm2))$delb  ## changed (0)
get("pp",environment(dfm2))$beta0 ## 0
dfm2(v)  ## failure
get("pp",environment(dfm2))$setDelb(5.463693)
get("pp",environment(dfm2))$delb
dfm2(v)  ## failure

ls(get("pp",environment(dfm2)))

## dfm2(v)
deviance(gm2)
dfm2 <- glmer(y ~ 1 + (1|block), d, Gamma, verbose = 50,
              devFunOnly=TRUE, nAGQ=1)

ff <- function(p,reset=TRUE) {
    r <- dfm2(p)
    if (reset) assign("dfm2",
        glmer(y ~ 1 + (1|block), d, Gamma, devFunOnly=TRUE, nAGQ=1),
                      .GlobalEnv)
    cat(p,r,"\n")
    r
}
opt1 <- optim(fn=ff,par=v)

## doesn't work even if I start at the right (?) value:
## probably thrown off by the initial
dfm3 <- glmer(y ~ 1 + (1|block), d, Gamma, nAGQ=1,
              start=list(theta=opt1$par[1],fixef=opt1$par[2]))

library(MASS)
g1 <- glmmPQL(y ~ 1,
        random=~1|block,
        data=d,
        family=Gamma)

opt1$par
fixef(g1)
VarCorr(g1)

