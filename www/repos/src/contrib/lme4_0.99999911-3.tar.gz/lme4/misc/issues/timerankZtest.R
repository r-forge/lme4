library(Matrix)
mm <- function(m,n) {
    Matrix(runif(m*n),nrow=m,ncol=n)
}
tt <- function(m,n) {
    cat(m,n,"\n")
    system.time(rankMatrix(mm(m,n)))["elapsed"]
}
nvec <- round(10^seq(0,4,by=0.5))
t_last <- 0
d <- expand.grid(m=nvec,n=nvec)
d <- d[d$m*d$n < 4e6,]
d$time <- apply(d,1,function(p) tt(p[1],p[2]))
d$prod <- d$m*d$n
library("ggplot2")
qplot(prod,time,data=d)+scale_y_log10()+scale_x_log10()
