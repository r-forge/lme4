library(lme4)
data = data.frame(y=1:5,u=c(rep("A",2),rep("B",3)),t=c(rep("A",3),rep("B",2)))
m = lmer(y ~ u + (1 | t),data)
m2 = lmer(y ~ u + (1 | u),data)
anova(m,m2) 
do.call(anova,list(m,m2))

if (FALSE) {
library(lme4.0)
data = data.frame(y=1:5,u=c(rep("A",2),rep("B",3)),t=c(rep("A",3),rep("B",2)))
m = lmer(y ~ u + (1 | t),data)
m2 = lmer(y ~ u + (1 | u),data)
anova(m,m2) 
do.call(anova,list(m,m2))
## Error in as.character.default(X[[1L]], ...) : 
##   no method for coercing this S4 class to a vector
}
