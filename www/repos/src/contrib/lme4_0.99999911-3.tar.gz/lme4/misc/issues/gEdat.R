load("gEdat.RData")
library(lme4)
## library(lme4.0)
## works with nAGQ=0 ... or with lme4.0
## (but false convergence warning)
g1 <- glmer(dead/total~fGen*species+(fGen|line0),
      family=binomial,weights=total,data=gEdat)
## Error: pwrssUpdate did not converge in 30 iterations

###############
capture.output(g1 <- glmer(dead/total~fGen*species+(fGen|line0),
                           family=binomial,
                           weights=total,data=gEdat,verbose=100),
               file="g1.out")

dfm2 <- glmer(dead/total~fGen*species+(fGen|line0),
      family=binomial,weights=total,data=gEdat,devFunOnly=TRUE,
              verbose=100)
s0 <- c(0.913263,-0.587069,0.385155,1.28309,
        1.19613,1.00462,-1.09125,1.9567,3.78592,
        -0.394721,-0.9104,-1.04053)
print(dfm2(s0),digits=20)  ## 2734.6679010638335967
## ridiculous, but:
putStuff <- function(x,basefn="tmp1") {
    for (i in ls(x)) {
        capture.output(print(x[[i]]),file=paste0(basefn,"_",i,".out"))
    }
}
putStuff(environment(dfm2)$pp)
putStuff(environment(dfm2)$resp)
capture.output(print(environment(dfm2)$lp0),file="tmp1_lp0.out")
## capture.output(show(environment(dfm2)$pp),file="tmp1.out")
debug(dfm2)
dfm2X <- deparse(dfm2)
dfm2X <- c(dfm2X[1:10],"cat('***\\n')","print(pars)",dfm2X[11:15])
dfm2Y <- eval(parse(text=dfm2X))
environment(dfm2Y) <- environment(dfm2)
optim(dfm2Y,par=s0) ## error
print(dfm2(s0),digits=20)  ## 2734.667462851557957
s_bad <- c(0.913263,-0.587069,0.385155,1.283090,1.196130,1.004620,-1.091250,
           1.956700,4.164512,-0.394721,-0.910400,-1.040530)
dfm2Y(s_bad)
putStuff(environment(dfm2)$pp,basefn="tmp2")
putStuff(environment(dfm2)$resp,basefn="tmp2")
capture.output(print(environment(dfm2)$lp0),file="tmp2_lp0.out")
testdiff <- function(x1,x2) {
    s <- system(paste("diff",x1,x2,">/dev/null"))
    s
}
vv <- c(ls(environment(dfm2)$pp),ls(environment(dfm2)$resp),"lp0")
testdiff("a1.txt","a2.txt")  ## different == 1
testdiff("a1.txt","a3.txt")  ## same == 0
changed <- setNames(sapply(vv,function(x) {
    testdiff(paste0("tmp1_",x,".out"),
             paste0("tmp2_",x,".out"))
}),vv)
changed[changed==1]
## capture.output(show(environment(dfm2)$pp),file="tmp2.out")

## could proceed further with this, using dput() rather than print()
## and using all.equal() to try to find components with a big difference
## rather than a tiny difference ...

## differences in: LamtUt
dfm2 <- glmer(dead/total~fGen*species+(fGen|line0),
      family=binomial,weights=total,data=gEdat,devFunOnly=TRUE,
              verbose=100)
print(dfm2(s0),digits=20)  ## back to original value

ctr <- 0
ff <- function(p,reset=TRUE,reset2=FALSE,maxct=Inf,dumpfile="ffdump.RData") {
    if (reset) assign("dfm2",
                      glmer(dead/total~fGen*species+(fGen|line0),
                            family=binomial,weights=total,data=gEdat,
                            devFunOnly=TRUE),
                      .GlobalEnv)
    ctr <<- ctr+1
    if (ctr==maxct) {
        save("dfm2","p",file=dumpfile)
        stop("hit maxct")
    }
    ## if (reset2) {
    ##     ## try to mess with the environment/ref classes
    ##     ## of dfm2 in a more subtle way
    ##     ## what are the potentially important pieces?
    ##     ##   baseOffset (??)
    ##     ee <- environment(dfm2)
    ##     ls(env=ee)
    ##     ee$pp$setDelb(rep(0,length(ee$pp$delb)))
    ##     ee$pp$setDelu(rep(0,length(ee$pp$delu)))
    ##     ee$pp$Xwts <- rep(1,length(ee$pp$Xwts))
    ##     ls(env=ee$pp)
    ## }
    r <- dfm2(p)
    cat(ctr,p,r,"\n")
    r
}
ctr <- 0
opt1 <- optim(ff,par=s0,maxct=8,dumpfile="ff_reset.RData")
ctr <- 0
opt2 <- optim(ff,par=s0,reset=FALSE,maxct=8,dumpfile="ff_noreset.RData")
## works but slow ... due to full resetting every time (!)

###

library(lme4)
L <- load("ff_reset.RData")
g0A <- glFormula(dead/total~fGen*species+(fGen|line0),
                 family=binomial,weights=total,data=gEdat)
g0B <- do.call(mkGlmerDevfun, g0A)

names(opt1)[2] <- "fval"
fit1 <- mkMerMod(environment(dfm2), opt1, g0A$reTrms, fr = g0A$fr)
save("fit1",file="gEdat_out1.RData")
load("gEdat_out1.RData")
library("lme4.0")
fit2 <- glmer(dead/total~fGen*species+(fGen|line0),
              family=binomial,weights=total,data=gEdat,verbose=100)
fit2_coef <- c(getME(fit2,"theta"),
               getME(fit2,"beta"))
detach("package:lme4.0")
## fit1 and fit2 are different but not VERY different
c(-2*logLik(fit1))  ## this says fit1 is slightly better
dfm2(fit2_coef)

##
opt2 <- optim(ff,par=s0, reset=FALSE)
opt2 <- optim(ff,par=s0, reset=FALSE,reset2=TRUE)
