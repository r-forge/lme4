## May 2013: rash of segmentation fault issues arising from 2.15 -> 3.0 shift
##   in some cases lme4 would crash very easily.
## to run R 2.15.3:
## export R_LIBS_SITE=./oldR; /usr/bin/R
get_pkgs <- TRUE
if (get_pkgs) {
    ## devtools dependencies
    install.packages(c("httr", "RCurl", "memoise", "whisker", "evaluate"),
                     dependencies=TRUE)
    download.file("http://cran.r-project.org/src/contrib/Archive/devtools/devtools_1.1.tar.gz",dest="devtools.tar.gz")
    install.packages("devtools.tar.gz",repos=NULL)
    ## lme4 dependencies
    install.packages(c("Rcpp","RcppEigen","minqa"))
    library("devtools")
    install_github("lme4","lme4")
}
library("lme4")
packageVersion("lme4")
lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
## lmod <- lFormula(Reaction ~ (1|Subject), data=sleepstudy)
## do.call(mkLmerDevfun, lmod)
