library(lme4)
if (!file.exists("xdata.csv")) 
    download.file("http://interactivecognition.com/files/xdata.csv",
                  dest="xdata.csv")
xdata <- read.csv("xdata.csv")
xmdl1 <- lmer(Response ~ Position + 
              StartSetup + StartDirection + TrialIndex +
              (1|Subject) + (1+Position|Subject),xdata)
VarCorr(xmdl1)  ## intercept var=0, subject/position var
print(lme4.0:::formatVC(VarCorr(xmdl1)),quote=FALSE)
## all zero with lme4.0
coef(xmdl1)

## The random slopes are all the same and the random effects variance is estimated to be 0.


## With the following, I get "unable to align random and fixed effects".

xmdl2=lmer(Response ~ Position + 
    StartSetup + StartDirection + TrialIndex +
    (1|Subject) + (0+Position|Subject),xdata)
VarCorr(xmdl2)
coef(xmdl2)

## Same happens with "lme4.0" instead of most recent version of lme4.

## Here's my attempt of a reduced form of this problem, similar to the data above:

set.seed(1)
resp <- trunc(runif(800,-30,30))
pred <- factor(rep(c("F","B"),400))
subj <- gl(10,80)
xmdl3 <- lmer(resp ~ pred + (1|subj) + (1+pred|subj))
coef(xmdl3)

## For context and Ben Bolker's previous response, see here:
## http://stackoverflow.com/questions/14485110/r-2-15-1-with-lme4-0-999999-0-unable-to-align-random-and-fixed-effects-or-zero

## 2 participants
## bbolker commented 9 days ago

## can't currently reproduce with lme4 (github/devel), lme4.0 (r-forge), or lme4 (fresh install from CRAN). R Under development (unstable) (2013-04-25 r62670); lme4_0.999999-2 Matrix_1.0-13. Can you re-test/re-confirm?
## strogg42 commented 16 hours ago

## Sorry for delayed response. I just re-tested this and still get the same problem. Doing...

coef(xmdl3)

## ... gives me same intercepts and same slopes for all subjects even though the model was specified otherwise and the intercepts and slopes should clearly differ (or at least, not be exactly equal). Does this make sense?

## The simulation reproduction of the error gives different intercepts, but doesn't give different slopes for "pred".


