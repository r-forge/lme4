setRefClass("ttt", fields = list(Lind = "integer", Ptr = "externalptr"))
n1 <- new("ttt")
library("Rcpp")
library("inline")
Rcpp::IntegerVector::create

SEXP xCreate(SEXP X) {
    x *ans = new x(X);
    return wrap(XPtr<x>(ans, true));
    END_RCPP;
}

