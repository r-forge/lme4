# TO DO (May 2013)


* downstream package tests
 * especially amer, blme, boss, BradleyTerry2, cplm, gamm4, odprism, pedigreemm, polytomous
* sparse X ???
* make glmer(...,family="gaussian") return a glmer object -- understand fitting process
* improve nlmer 
* improve lmer docs for control()
* check issues with residuals
* test Zhang et al runs with new glmer?

done
------------
* tests for overparameterization/lack of full rank in Z (done, but could be imporoved)
* trim tests for faster CRAN running: establish testing levels?
* restore robust GLMM functioning (r1705/1706) [SW]
* eval()/update issues  (done? check with J Roeby)
* formula eval issues (done? check with J Dushoff)
* convert grouping variables to factors automatically
* tests for overparameterization/lack of full rank in X
* finish @optinfo slot for convergence warnings etc.
* option to return random effects matrices in standard order/list form
* modularization -- API for resetting Z etc. (setME?)
