## collect glmm problems in one place (duplicates of other tests)
library(lme4)

## 1.
set.seed(101)
d <- expand.grid(block=LETTERS[1:26], rep=1:100, KEEP.OUT.ATTRS = FALSE)
d$x <- runif(nrow(d))  ## sd=1
reff_f <- rnorm(length(levels(d$block)),sd=1)
## need intercept large enough to avoid negative values
d$eta0 <- 4+3*d$x  ## fixed effects only
d$eta <- d$eta0+reff_f[d$block]

## Gamma, inverse link
d$mu <- 1/d$eta
d$y <- rgamma(nrow(d),scale=d$mu/2,shape=2)

gm2 <- glmer(y ~ 1 + (1|block), d, Gamma, verbose = 4)
## FAILURE MODE:
## first glmerLaplace iteration (?) works
## fails with inf in Nelder-Mead at first step ...


## 2. Error in pwrssUpdate(...); PIRLS step failed
dGi <- d
dGi$mu <- 1/d$eta ## inverse link
## make sd small enough to avoid negative values
dGi$y <- rnorm(nrow(d),dGi$mu,sd=0.01)
gGi1 <- glmer(y ~ 1 + (1|block), data=dGi, family=gaussian(link="inverse"), verbose= 3)

## 3. thailand/prLogistic example

## 4. crab example (assume we are currently in tests/ )
load("../testsx/randcrabdata.RData")
glmer1 <- glmer(fr2,weights=initial.snail.density,family ="binomial", data=randdata,
                        verbose=4)


