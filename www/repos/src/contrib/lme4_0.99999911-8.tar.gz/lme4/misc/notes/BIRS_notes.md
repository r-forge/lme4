BIRS meeting notes, take 1
====================

## Wish list

* flexible variance structures
* R-side effects
* post-hoc MCMC sampling
* speed-ups
 * general restructuring
 * handling special cases
* AGHQ for non-scalar RE
* nlmer
* weights	
* conditional variances of non-scalar RE
* post-fitting support ecosystem:
 * diagnostics
 * model summaries ($R^2$, ...)
 * posterior simulation
 * prediction
 * plotting
* multivariate responses
* Big Data: external storage etc.
* penalized approaches

## Projects (low-hanging fruit)
* release package-testing framework
* assess lme4 impact (Scopus/GScholar/etc.)

## Community

* resources for development
 * Google summer of code
 * Revolution???
 * RStudio?
* forums: r-sig-mixed-models, SO, ADMB users' list, ...
* maintenance?
* decisions about warnings etc. etc.?

## Infrastructure

(for work done at the meeting, and more generally for the project)

* Github vs R-forge
* Google docs?
* Travis (build system)
* (virtual repositories?)
