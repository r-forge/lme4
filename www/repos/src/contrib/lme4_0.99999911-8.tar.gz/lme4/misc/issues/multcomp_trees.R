library("lme4")
data("trees513", package = "multcomp")
trees513 <- subset(trees513, !species %in% c("fir", "softwood (other)"))
trees513$species <- trees513$species[,drop = TRUE]
## OR
## trees513 <- droplevels(subset(trees513, !species %in% c("fir", "softwood (other)")))
mmod <- glmer(damage ~ species - 1 + (1 | lattice / plot),
              data = trees513, family = binomial())

mmod <- lmer(damage ~ species - 1 + (1 | lattice / plot),
              data = trees513, family = binomial())
