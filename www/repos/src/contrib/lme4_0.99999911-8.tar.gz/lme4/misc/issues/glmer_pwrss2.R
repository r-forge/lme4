## an example that fails ("pwrssUpdate did not converge in 30 iterations")
## with current master branch, but succeeds (but shouldn't??) with
##  the lmeControl branch ... 
L <-load("regen_long_mle.RData")
library("lme4")
t1 <- system.time(m1 <- glmer(surv_mort ~ (1|ID) +
                              (1|block:treatment) + SDI * MCWD + h_t_minus_1 + offset(log(census_len)),
                              data=regen_long_mle, family=binomial(link="cloglog"),verbose=100,
                              control=glmerControl(check.rankZ.gtr.obs="ignore",tolPwrss=1e-5)))
dd <- update(m1,devFunOnly=TRUE)
dd <- glmer(surv_mort ~ (1|ID) +
                              (1|block:treatment) + SDI * MCWD + h_t_minus_1 + offset(log(census_len)),
                              data=regen_long_mle, family=binomial(link="cloglog"),verbose=100,
            control=glmerControl(check.rankZ.gtr.obs="ignore",tolPwrss=1),
            devFunOnly=TRUE)
debug(dd)
dd(rep(1,7))                  
