## testing identity, cloglog links, gaussian family
set.seed(1002)
nblock <- 10
nperblock <- 50
sd.u <- 1
beta <- c(0.2,0.5)
ntot <- nblock*nperblock
d <- data.frame(x=runif(ntot),f=factor(rep(LETTERS[1:nblock],each=nperblock)))
r <- rnorm(nblock,mean=0,sd=sd.u)
gshape <- 1.5
d$offset <- rgamma(ntot,1,1)
d <- within(d,
            {
              eta0 <- beta[1]+beta[2]*x+offset
              eta <- eta0+r[f]
            })


## cloglog:
cc <- binomial(link="cloglog")
d$mu0 <- cc$linkinv(d$eta0)
d$mu <- cc$linkinv(d$eta)

d$y0 <- rbinom(ntot,prob=d$mu0,size=1)
d$y <- rbinom(ntot,prob=d$mu,size=1)

## 

library(lme4)
g1A <- glmer(y~x+(1|f)+offset(offset),data=d,
             family=binomial(link="cloglog"),
             optimizer="bobyqa",
             control=glmerControl(tolPwrss=1e-3))

library(glmmADMB)
g1 <- glmmadmb(y~x+(1|f)+offset(offset),data=d,
               family="binomial",link="cloglog")

g1B <- glmer(y~x+(1|f)+offset(offset),data=d,
             family=binomial(link="cloglog"),
             start=list(fixef=coef(g1),
                        theta=sqrt(VarCorr(g1)[[1]])),
             control=glmerControl(tolPwrss=1e-3),
             verbose=20)
