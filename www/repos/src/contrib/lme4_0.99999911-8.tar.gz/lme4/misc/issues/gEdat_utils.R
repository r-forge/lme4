## utilities:

## compare files on disk
testdiff <- function(x1,x2) {
    s <- system(paste("diff",x1,x2,">/dev/null"))
    s
}

## dump (via dput) contents of an environment or reference class
putStuff <- function(x,basefn="tmp1") {
    for (i in ls(x)) {
        dput(x[[i]],file=paste0(basefn,"_",i,".out"))
    }
}

## retrieve files from disk and compare
getDiffs <- function(base="tmp") {
    require(stringr)

    res <- list()
    for (i in c("resp","pp")) {
        f_reset <- list.files(pattern=paste0(base,"_",i,"_reset"))
        f_noreset <- list.files(pattern=paste0(base,"_",i,"_noreset"))
        n <- length(f_reset)
        res[[i]] <- character(n)
        names(res[[i]]) <-  gsub("\\.out$","",gsub("tmp_[[:alpha:]]+_[[:alpha:]]+_","",f_reset))
        for (j in seq_along(f_reset)) {
            x1 <- eval(parse(f_reset[j]))
            x2 <- eval(parse(f_noreset[j]))
            res[[i]][j] <- all.equal(x1,x2)
        }
        res[[i]] <- res[[i]][res[[i]]!="TRUE"]
        res[[i]] <- str_extract(res[[i]],"[0-9.]+")
        storage.mode(res[[i]]) <- "numeric"
    }
    res
}

