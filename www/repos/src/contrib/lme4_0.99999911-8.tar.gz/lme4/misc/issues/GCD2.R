library("lme4")
packageVersion("lme4") ## ‘0.99999911.2’
GCD2 <- read.csv("GCD2.csv")
GCD2 <- na.omit(GCD2)
m1 <- lmer(Wxseed ~ (1|Sm), data=GCD2, na.action=na.omit, REML=TRUE)
ff <- update(m1,devFunOnly=TRUE)
d0 <- -2*c(logLik(m1))
svec <- 10^seq(-10,-1,length=51)
dvec <- sapply(svec,ff)-d0
VarCorr(m)
par(las=1,bty="l")
plot(svec,dvec,log="xy",type="b")
library(nlme)
m2 <- lme(Wxseed ~ 1,
          random= ~1|Sm,
          data=GCD2, na.action=na.omit, method="REML")
