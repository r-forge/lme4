library(lme4)

source("gEdat_utils.R")

## stage 1: run with and without resetting and dump files
load("gEdat.RData")
ctr <- 0  ## set counter so we can stop/dump environment at desired point
ff <- function(p,reset=TRUE,reset2=FALSE,maxct=Inf,dumpfile="ffdump.RData") {
    if (reset) assign("dfm2",
                      glmer(dead/total~fGen*species+(fGen|line0),
                            family=binomial,weights=total,data=gEdat,
                            devFunOnly=TRUE),
                      .GlobalEnv)
    ctr <<- ctr+1
    if (ctr==maxct) {
        save("dfm2","p",file=dumpfile)
        stop("hit maxct")
    }
    ## if (reset2) {
    ##     ## try to mess with the environment/ref classes
    ##     ## of dfm2 in a more subtle way
    ##     ## what are the potentially important pieces?
    ##     ##   baseOffset (??)
    ##     ee <- environment(dfm2)
    ##     ls(env=ee)
    ##     ee$pp$setDelb(rep(0,length(ee$pp$delb)))
    ##     ee$pp$setDelu(rep(0,length(ee$pp$delu)))
    ##     ee$pp$Xwts <- rep(1,length(ee$pp$Xwts))
    ##     ls(env=ee$pp)
    ## }
    r <- dfm2(p)
    cat(ctr,p,r,"\n")
    r
}

## create prepared deviance functions with environments etc.
##  primed for success or failure
ctr <- 0
opt1 <- optim(ff,par=s0,maxct=8,dumpfile="ff_reset.RData")
ctr <- 0
opt2 <- optim(ff,par=s0,reset=FALSE,maxct=8,dumpfile="ff_noreset.RData")

## stage 2. Read them back in, in separate R sessions, and trace ...
L <- load("ff_reset.RData")
debug(dfm2)
dfm2(p) ## [1] 2756.894
L <- load("ff_noreset.RData")
debug(dfm2)
dfm2(p) ## [1] error

## deparse and hack 'putStuff' statements in throughout??
dfm2T <- deparse(dfm2)

## step through in paired windows

dput(lp0,"tmp1.txt")
dput(lp0,"tmp2.txt")
testdiff("tmp1.txt","tmp2.txt") ## lp0 is identical

b <- "reset"
b <- "noreset"
for (i in c("pp","resp")) {
    putStuff(get(i),paste("tmp",i,b,sep="_"))
}

## what is difference between the environments going into this step?
## pp
## resp
## parent.env(environment()) ?

## step 1: pp$delu are slightly different (?)
## resp$eta are very different!
rr1 <- getDiffs()
rr2 <- getDiffs()

## why is mu different?  why doesn't updateMu fix the differences?
##  where is d_offset stored?
## where does eta get set?
