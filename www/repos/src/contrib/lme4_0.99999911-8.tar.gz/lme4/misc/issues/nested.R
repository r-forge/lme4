tmpf <- function() {
    lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
}
tmpf()
