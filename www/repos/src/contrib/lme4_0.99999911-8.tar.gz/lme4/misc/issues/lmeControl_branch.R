## noticeable differences
## refit (elston.R)
## bacteria example comparison with previous values (glmer-1.R)

## add an attribute to test whether the correct control function is called??
