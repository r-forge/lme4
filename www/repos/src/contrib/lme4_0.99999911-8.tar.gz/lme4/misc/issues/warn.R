testfun <- function(...) {
    warning("test warning system")
}

curWarnings <- list()
arglist <- list()

opt <- withCallingHandlers(do.call(testfun,arglist),
                           warning = function(w) {
                               curWarnings <<- append(curWarnings,list(w$message))
                           })
curWarnings

library(testthat)
expect_warning(opt <- withCallingHandlers(do.call(testfun,arglist),
                           warning = function(w) {
                               curWarnings <<- append(curWarnings,list(w$message))
                           }))

