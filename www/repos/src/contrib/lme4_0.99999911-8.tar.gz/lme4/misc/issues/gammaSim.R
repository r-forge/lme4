 ## trying to figure out shape parameters, weighted residuals, etc.
## there's only a _single_ updateWrss, which is:
## 	d_wtres = d_sqrtrwt.cwiseProduct(d_y - d_mu);
##      d_wrss  = d_wtres.squaredNorm();

## and updateWts() gives
##	d_sqrtrwt = d_weights.array() / variance().sqrt();
## i.e.  w_i/sqrt(v_i) ?


## an unnecessarily complex/general simulation function ...
gSim <- function(nblk=26,  
                 nperblk=100,
                 sigma=1,
                 beta=c(4,3),
                 shape=2,    ## shape parameter for Gamma
                 nbinom=10,  ## N for binomial trials
                 family=Gamma()) {
    d <- expand.grid(block=LETTERS[1:nblk],
                     rep=1:nperblk, KEEP.OUT.ATTRS = FALSE)
    d$x <- runif(nrow(d))  ## sd=1
    reff_f <- rnorm(length(levels(d$block)),sd=sigma)
    ## need intercept large enough to avoid negative values
    d$eta0 <- beta[1]+beta[2]*d$x  ## fixed effects only
    d$eta <- d$eta0+reff_f[d$block]
    d$mu <- family$linkinv(d$eta)
    d$y <- switch(family$family,
                  Gamma=rgamma(nrow(d),scale=d$mu/shape,shape=shape),
                  poisson=rpois(nrow(d),d$mu),
                  binomial=if (nbinom==1) {
                      rbinom(nrow(d),prob=d$mu,size=1)
                  } else 
              {z <- rbinom(nrow(d),prob=d$mu,size=nbinom);
               cbind(succ=z,fail=nbinom-z)})
    d
}

glmFit <- function(...) {
    g0 <- glm(y~x,data=gSim(...),family=Gamma)
    c(coef(g0),dispersion=summary(g0)$dispersion,rvar=NA)
}


glmmFit <- function(...) {
    require(lme4)
    glmer(y~x+(1|block),data=gSim(...),family=Gamma)
}

replicate(20,glmFit(sigma=0)["dispersion"])
rr <- t(replicate(20,glmmFit()))

set.seed(1001)
## hand-coded Pearson residuals
mypresid <- function(x) {
    mu <- fitted(x)
    (getME(x,"y")-mu)/sqrt(x@resp$family$variance(mu))
}
sumFun <- function(m) {
    ## sum of weighted residuals, 3 ways
    wrss1 <- m@devcomp$cmp["wrss"]
    wrss2 <- sum(residuals(m,type="pearson")^2)
    wrss3 <- sum(m@resp$wtres^2)
    wrss4 <- sum(mypresid(m)^2)
    c(wrss1,wrss2,wrss3,wrss4)
}
set.seed(101)

## GAMMA
g0 <-  glmer(y~x+(1|block),data=gSim(),family=Gamma)
sumFun(g0)
## fails, a little bit ...
##     wrss                            
## 1252.444 1252.444 1252.444 1259.548 

## BERNOULLI
g1 <-  glmer(y~x+(1|block),data=gSim(family=binomial(),nbinom=1),
             family=binomial)
sumFun(g1)

## POISSON 
g2 <-  glmer(y~x+(1|block),data=gSim(family=poisson()),
             family=poisson)
sumFun(g2)

d <- gSim(family=poisson())
g2W <-  glmer(y~x+(1|block),data=d,
             family=poisson,weights=rep(2,nrow(d)))
sumFun(g2W)
##      wrss                               
## 10661.569 10661.569 10661.569  2665.392
## factor of 5?

## 989474.360 989474.360 989474.360   2558.142 

g3 <-  glmer(y~x+(1|block),data=gSim(family=binomial(),nbinom=10),
             family=binomial)
sumFun(g3)

dc <- g0@devcomp
## wrss=64.86; pwrss=80.41
w <- model.weights(model.frame(g0))  ## not specified??
wrss <- g0@devcomp$cmp["wrss"]
wrss2 <- sum(residuals(g0,type="pearson")^2)
wrss3 <- sum(g0@resp$wtres^2)
## agree

fm1 <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
wrss <- fm1@devcomp$cmp["wrss"]
sum(residuals(fm1)^2)

## for Poisson, all three components agree
set.seed(101)
g2 <- glmer(y~x+(1|block),data=gSim(family=poisson()),family=poisson)
## all three match
wrss <- g2@devcomp$cmp["wrss"]
wrss2 <- sum(residuals(g2,type="pearson")^2) ## matches
wrss3 <- sum(g2@resp$wtres^2)
all.equal(range(resid(g2,"pearson")),range(g2@resp$wtres))

mypresid <- function(x) {
    mu <- fitted(x)
    w <- weights(x)
    (getME(x,"y")-mu)*sqrt(w)/sqrt(x@resp$family$variance(mu))
}
range(resid(g2,"pearson"))  ## ?? huge ??
all.equal(range(resid(g2,"pearson")),range(g2@resp$wtres))
range(mypresid(g2))

## Bernoulli: all match
g3 <- glmer(y~x+(1|block),data=gSim(family=binomial(),nbinom=1),family=binomial)
wrss <- g3@devcomp$cmp["wrss"]
wrss2 <- sum(residuals(g3,type="pearson")^2) ## matches
wrss3 <- sum(g3@resp$wtres^2)
range(resid(g3))
all.equal(range(resid(g3,"pearson")),range(g3@resp$wtres))
sum(mypresid(g3)^2)

## binomial: all match
g4 <- glmer(y~x+(1|block),data=gSim(family=binomial(),nbinom=10),family=binomial)
wrss <- g4@devcomp$cmp["wrss"]
wrss2 <- sum(residuals(g4,type="pearson")^2) ## matches
wrss3 <- sum(g4@resp$wtres^2)
