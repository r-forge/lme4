load(system.file("testdata","confint_ex.rda",package="lme4"))
parNames <- rownames(fm1B)
parNames <- c(parNames[1:3],"sigma",parNames[4:5])
parEsts <- c(getME(fm1,"theta"),sigma(fm1),fixef(fm1))
## skip intercept
intercept <- 5  ## intercept position
op <- par(mar=c(5,7,2,2)+0.1)
xpos <- 1:5
plot(parEsts[-intercept],xpos,axes=FALSE,bty="l",ylab="",xlab="value")
axis(side=1)
abbNames <- abbreviate(parNames[-intercept],minlength=12)
axis(side=2,at=1:5,label=abbNames,las=1)
offset <- 0.3
segments(fm1P[-intercept,1],xpos-offset,fm1P[-intercept,2],xpos-offset)
