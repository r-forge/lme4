library(lme4.0)
fm1_old <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
Zt_old <- fm1_old@Zt
Zt_old2 <- getME(fm1_old,"Zt")
detach("package:lme4.0")
library(lme4)
fm1_new <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
Zt_new <- getME(fm1_new,"Zt")
Zt_newList <- getME(fm1_new,"Ztlist")
library(Matrix)
Zt2 <- do.call(rBind,Zt_newList)
all.equal(unname(Zt_old),unname(Zt2))

