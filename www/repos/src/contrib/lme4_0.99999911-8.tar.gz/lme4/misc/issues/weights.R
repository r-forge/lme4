## sample size weighted LMM
#
#
library(nlme)
library(lme4)
#generate some lognormal random effects (i.e. level-2)
Nsamp <- rep(0,50)
set.seed(101)
REs <- rnorm(n=50, mean=0, sd=0.3)
#generate some within residual errors (i.e. level-1)
RES <- NULL
Xf <- NULL
X <- NULL
for (i in 1:50) {
## Nsamp[i] <- rpois(n=1,lambda=20)
    Nsamp[i] <- 1
    RES <- c(RES,rep(REs[i],each=Nsamp[i]))
    Xi <- as.integer(i/10)
    X <- c(X,rep(Xi,each=Nsamp[i]))
    Xf <- c(Xf,rep(i,each=Nsamp[i]))
}

RES <- RES + rnorm(n=length(RES), mean=0, sd=0.1)
RE.Xf <- as.factor(Xf)

#set up regression model
Y <- 1 + 5*X + RES

# calculate means and fit weighted LMM with random lack-of-fit term

Ym <- as.vector(tapply(X=Y, INDEX=RE.Xf, FUN=mean))
Xm <- as.vector(tapply(X=X, INDEX=RE.Xf, FUN=mean))

Xm.f <- as.factor(Xm)
wts <- 1/Nsamp

lme.av <- lme(fixed=Ym ~ Xm, random=~1|Xm.f, weights=varFixed(~wts))
summary(lme.av)

printCoefmat(summary(nlme.av)$tTable)

lmer.av <- lmer(formula=Ym ~ Xm + (1|Xm.f), weights=Nsamp)
summary(lmer.av)
coef(summary(lmer.av))

fixef(lmer.av)/fixef(lme.av)
sqrt(20)

## coefficients are scaled wrong for LMMs
