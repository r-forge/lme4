## http://stats.stackexchange.com/questions/44755/binomial-glmm-not-converging-random-effects-variance-and-stdev-1-resulting-i
## Spotties v. Bullies - Generalized Linear Mixed Models - Binomial
## AFTER DA / After GLM with means
## Nov 37, 2012

## simplified version (BMB)

# GLMs with glmML package is having problems. (See SvB_GLMM3..) try with lme4 package

# Get data:
# File frogs_glm includes data refinements from DSFrogs in files SvB_GLM and SvB_GLMM. 
# Refinements involved combining habitat features into fewer indices.

Frogs <- read.csv(file = "frogs_glm.csv")

library(lattice)

## Log-transform euclidean distances: hard.dep, near.edge, veg.ht, cover.dep
Frogs <- transform(Frogs,
                   l.hard.dep = log1p(hard.dep),
                   l.near.edge = log1p(near.edge),
                   l.veg.ht = log1p(veg.ht))
# bind into new Frogs data matrix
Frogs <- subset(Frogs,select=-c(hard.dep,veg.ht,near.edge))

######################################################
library("lme4")

# Model with all from VIF < 4, except for surf.openwater
t1 <- system.time(M1 <- glmer(pt.type ~ 
                              tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge + l.veg.ht
                              + (1 | frog), 
                              data = Frogs, family = binomial))

## get VERY LARGE
M1_drop1 <- drop1(M1)

# failure to converge  (warning)
# remove surf.land  ## BMB: why?
M2 <- update(M1, . ~ . - surf.land)

anova(M1,M2)
## uh-oh.  How can M2 have a _much_ lower AIC??

r1 <- resid(M1, type = "pearson")

## pp <- profile(M2)  ## fails
# Error in zeta(pw * 1.01, start = opt[seqpar1][-w]) : 
# 	profiling detected new, lower deviance

# remove em.dens
M3 <- update(M2, . ~ . - em.dens)
drop1(M3)

# indicates that dropping l.veg.ht will result in AIC of infinity.. 
M1b 
# remove tac.ii or float.dens or l.near.edge
# remove tac.ii first

M1bi <- glmer(pt.type ~ 
	float.dens + l.hard.dep + l.near.edge + l.veg.ht
			  + (1 | frog), 
			  data = Frogs, family = binomial)
# failure to converge

# remove float.dens



Mveg <- glmer(pt.type ~ l.veg.ht + (1|frog), data = Frogs, family = binomial)
Mveg

# remove l.veg.ht
M2 <- glmer(pt.type ~ 
			tac.ii + em.dens + float.dens + l.hard.dep + l.near.edge 
			+ (1 | frog), 
			data = Frogs, family = binomial)
M2
drop1(M2)
anova(Mvif, M1, M2)



?Inf

M3 <- glmer(pt.type ~ 
			tac.ii + em.dens + float.dens + l.hard.dep
			+ (1 | frog), 
			data = Frogs, family = binomial)
M3

corvif(Frogs[,c("tac.ii", "em.dens", "float.dens", "l.hard.dep")])
pairs(Frogs[,c("tac.ii", "em.dens", "float.dens", "l.hard.dep")], lower.panel = panel.cor)

drop1(M3)
fixef(M3)

M4 <- glmer(f.pt.type ~ em.dens + l.hard.dep + l.veg.ht
			+ (1 | frog), 
			data = Frogs, family = binomial)
M4
fixef(M4)
plot(M4)

E4 <- resid(M4, type = "pearson")
plot(E4 ~ l.hard.dep, Frogs)

anova(Mvif,M1,M2,M3,M4)


# Try Predictions

# Oregon spotted frogs will use shallower habitats than bullfrogs:
# H0: l.hard.dep | OSF = l.hard.dep | BF
# H1: l.hard.dep | OSF < l.hard.dep | BF

Mhard <- glmer(f.pt.type ~ l.hard.dep + (1 | frog),
		 data = Frogs,
		  family = binomial)
# AIC: Inf again!


# Standardize data:
str(Frogs)
scaled <- scale(Frogs[,c(5:13)])
Frogs.st <- cbind(Frogs[,c(1:4)], scaled)

MS1 <- glmer(pt.type ~ 
	tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			  + (1 | frog), 
			  data = Frogs.st, family = binomial)
MS1
drop1(MS1)
# drop l.veg.ht
MS1a <- glmer(pt.type ~ 
	tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge 
			 + (1 | frog), 
			 data = Frogs.st, family = binomial)
# failure to converge


# remove tac.ii
MS2 <- glmer(pt.type ~ 
	em.dens + surf.land + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			 + (1 | frog), 
			 data = Frogs.st, family = binomial)
MS2
drop1(MS2)
# failure to converge - then Inf scores..

# remove l.near.edge
MS3 <- glmer(pt.type ~ 
	em.dens + surf.land + float.dens + l.hard.dep + l.veg.ht
			 + (1 | frog), 
			 data = Frogs.st, family = binomial)
MS3

anova(MS3,MS2)

# 
MS3b <- glmer(pt.type ~ 
	em.dens  + float.dens + l.hard.dep 
					+ (1 | frog), 
					data = Frogs.st, family = binomial)
MS3b
anova(MS3,MS3b)

?glmer


###########################################
# Bolker recommends using Laplace or GHQ algorithms for binary data with <3 random effects

# glmer uses Laplace by default through the setting nAGQ = 1. If nAGQ > 1, uses GHQ instead
# http://pl.digipedia.org/usenet/thread/14648/3565/ recommends increasing the number until 
# results don't change much. GHQ is a more accurate method, but takes more computing time.
# This is irrelevant with my data. Do both methods to see if any differences:

M1laplace <- glmer(pt.type ~ 
					tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge + l.veg.ht
					+ (1 | frog), 
					data = Frogs.st, family = binomial)

M1ghq <- glmer(pt.type ~ 
					tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge + l.veg.ht
				   + (1 | frog), 
				   data = Frogs.st, family = binomial, nAGQ = 3)
# failure to converge
M1laplace
drop1(M1laplace)
# failure to converge, success on second try:
# drop l.veg.ht
M1lp1 <- glmer(pt.type ~ 
				tac.ii + em.dens + surf.land + float.dens + l.hard.dep + l.near.edge 
				+ (1 | frog), 
				data = Frogs.st, family = binomial)
# failure to converge



# remove surf.land from both

M2lp <- glmer(pt.type ~ 
			tac.ii + em.dens + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			  + (1 | frog), 
			  data = Frogs.st, family = binomial)
# ok
M2ghq <- glmer(pt.type ~ 
			tac.ii + em.dens + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			   + (1 | frog), 
			   data = Frogs.st, family = binomial, nAGQ = 3)
# ok

M2lp
M2ghq
anova(M2lp, M2ghq)     # M2ghq improved on M2lp
anova(M1laplace, M2lp) # no difference between M1 and M2 (Laplace)

# remove tac.ii from both
M3lp <- glmer(pt.type ~ 
			em.dens + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			  + (1 | frog), 
			  data = Frogs.st, family = binomial)
#ok
M3ghq <- glmer(pt.type ~ 
				em.dens + float.dens + l.hard.dep + l.near.edge + l.veg.ht
			   	+ (1 | frog), 
			   	data = Frogs.st, family = binomial, nAGQ = 3)
#ok
M3lp            # ok - AIC: 156
drop1(M3lp)     # failure to converge, success on 3rd attempt but next level will have AIC: Inf
M3ghq           # AIC Inf
drop1(M3ghq)
# test M3lp v. M2ghq
anova(M3lp, M2ghq)
# M2ghq better model
M2ghq # no significance of p-values

#remove em.dens

M4lp <- glmer(pt.type ~ 
				float.dens + l.hard.dep + l.near.edge + l.veg.ht
			  + (1 | frog), 
			  data = Frogs.st, family = binomial)
# failure to converge
M4ghq <- glmer(pt.type ~ 
				float.dens + l.hard.dep + l.near.edge + l.veg.ht
			   + (1 | frog), 
			   data = Frogs.st, family = binomial, nAGQ = 3)

# M4ghq still works

M4ghq   # significance of effects in 3/4 variables,
# But AIC INf, Random Effects variance and std dev are < 1.
# no anova possible

# Remove l.near.edge
M5ghq <- glmer(pt.type ~ 
			float.dens + l.hard.dep +  l.veg.ht
			   + (1 | frog), 
			   data = Frogs.st, family = binomial, nAGQ = 3)

M5ghq    # significance of effects in all 3 variables,
# But AIC INf, Random Effects variance and std dev are = 1.

# Try increasing nAGQ?
M4ghq5 <- glmer(pt.type ~ 
			float.dens + l.hard.dep + l.veg.ht
			   + (1 | frog), 
			   data = Frogs.st, family = binomial, nAGQ = 5)

M4ghq5 # same #s as M4ghq with nAGQ = 3
