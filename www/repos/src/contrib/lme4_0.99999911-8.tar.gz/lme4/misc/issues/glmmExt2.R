library("lme4")

set.seed(102)  ## doesn't fail with set.seed(101)
d <- expand.grid(block=LETTERS[1:26], rep=1:100, KEEP.OUT.ATTRS = FALSE)
d$x <- runif(nrow(d))  ## sd=1
reff_f <- rnorm(length(levels(d$block)),sd=1)
## need intercept large enough to avoid negative values
d$eta0 <- 4+3*d$x  ## fixed effects only
d$eta <- d$eta0+reff_f[d$block]
dBc <- d
cc <- binomial(link="cloglog")
dBc$mu <- cc$linkinv(d$eta - 5)         # -5, otherwise y will be constant
dBc$y <- factor(rbinom(nrow(d),dBc$mu,size=1))
save("dBc",file="glmmExt2.rda")

##

## Ctrl-U Meta-X R 
## -d gdb <Enter>
## (Ctrl-G)
## run

library("lme4")
load("glmmExt2.rda")

## Ctrl-C Ctrl-C
## in gdb: break external.cpp:319 if i==4 (pwrssUpdate)
## cont

gBc2 <- glmer(y ~ x + (1|block), data=dBc,
              family=binomial(link="cloglog"), nAGQ=0, verbose=100)


##     pdev goes to nan  on pwrssUpdate step 3 next need
##    to check inside internal_glmerWrkIter to see
##    precisely where the problem lies
##    (updateXwts -> updateDecomp -> updateRes -> solve -> updateMu -> sqrL)

## first nan is 'resDev after updateMu' in this step (this *might* change
##  based on debugging statements???)

## No: variance is bounded at epsilon anyway, x1mx function (glmFamily.cpp:69)
## we'll have to do some more stepping ...
