library(lme4)
load(system.file("testdata","culcita_dat.RData",package="lme4"))
cmod <- glmer(predation~ttt+(1|block),family=binomial,data=culcita_dat)
set.seed(101)
## debug(confint.merMod)
## debug(bootMer)
cc <- confint(cmod,method="boot",nsim=10,quiet=TRUE,
              .progress="txt")
