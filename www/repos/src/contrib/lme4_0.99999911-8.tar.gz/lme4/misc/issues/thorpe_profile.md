Profiling issue
================


```r
library("lme4")
load("oct.RData")
```


Fit model and profile:

```r
(oct.lmer1 <- lmer(OCT ~ doseperkg + (1 | Pt), data = oct, REML = FALSE))
```

```
## Linear mixed model fit by maximum likelihood ['lmerMod']
## Formula: OCT ~ doseperkg + (1 | Pt) 
##    Data: oct 
## 
##      AIC      BIC   logLik deviance 
##   1322.7   1333.5   -657.3   1314.7 
## 
## Random effects:
##  Groups   Name        Variance Std.Dev.
##  Pt       (Intercept) 6683     81.7    
##  Residual             6441     80.3    
## Number of obs: 109, groups: Pt, 34
## 
## Fixed effects:
##             Estimate Std. Error t value
## (Intercept)   407.56      21.88   18.63
## doseperkg       0.24      16.42    0.01
## 
## Correlation of Fixed Effects:
##           (Intr)
## doseperkg -0.680
```

```r
xxx <- profile(oct.lmer1)
```

```
## Warning: convergence code 3 from bobyqa: bobyqa -- a trust region step
## failed to reduce q
```


Default plot method (somewhat ugly):

```r
plot(xxx)
```

![plot of chunk unnamed-chunk-3](figure/unnamed-chunk-3.png) 


`xyplot` (much prettier):

```r
xyplot(xxx)
```

![plot of chunk unnamed-chunk-4](figure/unnamed-chunk-4.png) 


`splom`:

```r
splom(xxx)
```

![plot of chunk unnamed-chunk-5](figure/unnamed-chunk-5.png) 

