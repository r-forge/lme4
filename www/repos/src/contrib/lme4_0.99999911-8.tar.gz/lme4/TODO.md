# TO DO (July 2013)

## Release critical

* downstream package tests
 * especially blme, cplm, odprism, polytomous

## More or less finished, or easy, but not pushed
 * check issues with weights
 * drop1 with user-specified functions
 * update getME, bootMer, profile names
 * p-value document (lmerTest Satterthwaite, pbkrtest, car::Anova ..., bootMer)
 * remove/fix mcmcsamp documentation
 * decide on a NEWS strategy

## Release important (not critical): pre-feature freeze 

* mods for `blme`, `arm` packages: Vince Dorie: expose `lm_setTheta`, `lm_updateDecomp`, `lm_updateMu`; writeup
* `bdiag(VarCorr(...))` examples
* test `mustart`, `etastart`, `verbose` actually working/documented

## Lower priority

* load/unload/segfault issues (punted to Rcpp folks)
* sparse X ???
* make glmer(...,family="gaussian") return a glmer object -- understand fitting process (related to blme/sim)
* improve nlmer (test, documentation, allow to run without derivs, make fixed effects easier)
* test Zhang et al runs with new glmer?
* make `arm::sim()`, `blme`, `drop1(...,"pbkrtest")`, ... work? (note car::Anova.lmer has a drop1 option)

## Blue sky/wishlist

* R-side effects (spatial, geospatial, phylogenetic, temporal correlation)
* V-C structure (ditto; cf. MCMCglmm/AS-REML structures)
* Restore mcmcsamp
* AGQ for more complex models

## Done

* improve control interface
* tests for overparameterization/lack of full rank in Z (done, but could be imporoved)
* trim tests for faster CRAN running: establish testing levels?
* restore robust GLMM functioning (r1705/1706) [SW]
* eval()/update issues  (done? check with J Roeby)
* formula eval issues (done? check with J Dushoff)
* convert grouping variables to factors automatically
* tests for overparameterization/lack of full rank in X
* finish @optinfo slot for convergence warnings etc.
* option to return random effects matrices in standard order/list form
* modularization -- API for resetting Z etc. (setME?)
