testfun <- function() {
   lme4::lmer(Reaction~Days+(1|Subject),sleepstudy)   
}
