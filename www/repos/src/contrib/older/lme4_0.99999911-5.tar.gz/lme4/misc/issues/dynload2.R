#!/usr/bin/r

library(RcppEigen)
library(digest)
example(digest)
detach(package:digest,unload=TRUE)
## detach(package:digest)
detach(package:RcppEigen,unload=TRUE)

library(RcppEigen)
library(digest)
example(digest)

cat("Done\n")

for (i in 1:10) {
    cat(i,"\n")
    library(RcppEigen)
    capture.output(example(fastLm))
    detach(package:RcppEigen,unload=TRUE)
    library(nlme)
    detach(package:nlme)
}
cat("Done\n")
