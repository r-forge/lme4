library(lme4)
debug(lFormula)
system.time(fm2 <- lmer(y ~ service*dept + (1|s) + (1|d), InstEval, REML=FALSE))
dim(reTrms$Zt) ## 4100 x 73421


(doCheck(cc <- control[[cstr]]) &&                   ## not NULL or "ignore"
        !(grepl("Small",cc) && prod(dim(reTrms$Zt))>1e6)    ## not "*Small" and large Z mat
        && (nrow(fr) <= (rankZ <- rankMatrix(reTrms$Zt))))
