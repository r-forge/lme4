curve(1/(1+exp(-x)),from=-5,to=10)
curve(exp(-exp(-x)),add=TRUE,col=2)
## log(complement of logistic)

curve(1-1/(1+exp(-x)),from=0,to=100,log="y")
## cloglog:
curve(1-exp(-exp(-x)),add=TRUE,col=2)

curve(plogis(x,lower.tail=FALSE),from=0,to=100,log="y")
library(evd)
curve(pgumbel(x,lower.tail=FALSE),col=2,add=TRUE)
