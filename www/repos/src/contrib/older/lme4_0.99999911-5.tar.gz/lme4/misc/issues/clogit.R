library(survival)
library(metafor)

### number of pairs
n <- 100

### create some data
ai <- c(rep(0,n/2), rep(1,n/2))
bi <- 1-ai
ci <- c(rep(0,42), rep(1,8), rep(0,18), rep(1,32))
di <- 1-ci

### matched pair data
tab <- table(ai,ci)
tab

### McNemar's test
mcnemar.test(table(ai,ci))

### conditional ML estimator of log(OR) and corresponding SE
round(log(tab[2,1]/tab[1,2]),4)
round(sqrt(1/tab[2,1] + 1/tab[1,2]),4)

### n x 2 x 2 stratified data analysis with CMH test
rma.mh(ai=ai, bi=bi, ci=ci, di=di, measure="OR")

### change data to long format 
event <- c(rbind(ai,ci))
group <- rep(c(1,0), times=n)
id    <- rep(1:n, each=2)

### conditional logistic model
summary(clogit(event ~ group + strata(id)))

########################################################################

## So, all matches up as expected. An alternative approach to estimating the model above is described, for
## example, in Agresti (2002), chapter 10 (esp. 10.2.4). Here, the alpha_i values are treated as random
## effects, typically assumed to be drawn from N(mu, sigma^2). So, let's try out this approach, using lmer():

########################################################################

library(lme4)
library(lme4.0)
g0 <- glmer(event ~ group + (1 | id), family=binomial, nAGQ=21)
afun <- function(n) fixef(update(g0,nAGQ=n))[2]
vec <- sapply(1:25,afun)
plot(1:25,vec,ylim=c(0.809,0.811))  ## 25 is max
