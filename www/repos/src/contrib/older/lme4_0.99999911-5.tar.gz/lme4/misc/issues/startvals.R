## From: http://stackoverflow.com/questions/17321153/restart-mixed-effect-model-estimation-with-previously-estimated-values
library(lme4)

# Fit model with limited number of iterations

frm <- "Sepal.Length ~ Sepal.Width | Species"

c1 <- capture.output(x <- lmer(frm, data=iris, 
          verbose=TRUE, control=list(maxIter=1), model=FALSE))

# Capture starting values for next set of iterations
start <- list(ST=x@ST)

# Update model
c2 <- capture.output(twoStep <-  lmer(frm, data=iris, 
          verbose=TRUE, control=list(maxIter=100), model=TRUE, 
          start=start))

## This works. Take a look at the output, where the first column is the REML, i.e. the random effect maximum likelihood. Notice especially that the REML in model 2 starts where model 1 terminates:

However, when I have a different value of maxIters this no longer works:

c3 <- capture.output(x <- lmer(frm, data=iris, 
          verbose=TRUE, control=list(maxIter=3), model=FALSE))
start <- list(ST=x@ST)
c4 <- capture.output(twoStep <-  lmer(frm, data=iris, 
                 verbose=TRUE, control=list(maxIter=100), model=TRUE, 
                 start=start))

Notice that the REML value restarts at 264, i.e. the beginning:

> x <- lmer(frm, data=iris, 
+           verbose=TRUE, control=list(maxIter=3), model=FALSE)
  0:     264.60572: 0.230940 0.0747853  0.00000
  1:     204.22878: 0.518238  1.01025 0.205835
  2:     201.94075:  0.00000  1.51757 -1.18259
  3:     201.71473:  0.00000  1.69036 -1.89803
  3:     201.71473:  0.00000  1.69036 -1.89803

> # Capture starting values for next set of iterations
> start <- list(ST=x@ST)

> # Update model
> twoStep <-  lmer(frm, data=iris, 
+           verbose=TRUE, control=list(maxIter=100), model=TRUE, 
+           start=start)
