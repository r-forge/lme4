# TO DO (May 2013)

## Release critical

* load/unload/segfault issues (!!)
* update info page on R-forge, README.md
* downstream package tests
 * especially amer, blme, boss, BradleyTerry2, cplm, gamm4, odprism, pedigreemm, polytomous

## Release important (not critical) 
* check issues with residuals
* Vince Dorie: expose lm_setTheta, lm_updateDecomp, lm_updateMu; writeup
* bdiag(VarCorr(...)) examples
* test 'start', 'mustart', 'etastart', 'verbose' actually working/documented

## Lower priority

* check issues with weights
* sparse X ???
* make glmer(...,family="gaussian") return a glmer object -- understand fitting process (related to blme/sim)
* improve nlmer (test, documentation, allow to run without derivs, make fixed effects easier)
* test Zhang et al runs with new glmer?
* make `arm::sim()`, `blme`, `drop1(...,"pbkrtest")`, ... work? (note car::Anova.lmer has a drop1 option)
* double check that `start`, `verbose` etc. work correctly

## Blue sky/wishlist

* R-side effects (spatial, geospatial, phylogenetic, temporal correlation)
* V-C structure (ditto; cf. MCMCglmm/AS-REML structures)
* Restore mcmcsamp


## Done

* improve control interface
* tests for overparameterization/lack of full rank in Z (done, but could be imporoved)
* trim tests for faster CRAN running: establish testing levels?
* restore robust GLMM functioning (r1705/1706) [SW]
* eval()/update issues  (done? check with J Roeby)
* formula eval issues (done? check with J Dushoff)
* convert grouping variables to factors automatically
* tests for overparameterization/lack of full rank in X
* finish @optinfo slot for convergence warnings etc.
* option to return random effects matrices in standard order/list form
* modularization -- API for resetting Z etc. (setME?)
