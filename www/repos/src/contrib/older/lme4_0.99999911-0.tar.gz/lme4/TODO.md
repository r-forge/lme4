# new TO DO (Nov 2012)

* restore robust GLMM functioning (r1705/1706) [SW]
* downstream package tests
 * especially amer, blme, boss, BradleyTerry2, cplm, gamm4, odprism, pedigreemm, polytomous
* trim tests for faster CRAN running: establish testing levels?
* tests for overparameterization/lack of full rank in Z
* sparse X ???
* make glmer(...,family="gaussian") return a glmer object
* finish @optinfo slot for convergence warnings etc.
* option to return random effects matrices in standard order/list form
* improve nlmer 
* modularization -- API for resetting Z etc. (setME?)
* improve lmer docs for control()

done
------------
* eval()/update issues  (done? check with J Roeby)
* formula eval issues (done? check with J Dushoff)
* convert grouping variables to factors automatically
* tests for overparameterization/lack of full rank in X
