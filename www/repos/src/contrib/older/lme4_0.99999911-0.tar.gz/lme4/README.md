lme4
====

Mixed-effects models in R using S4 classes and methods with RcppEigen