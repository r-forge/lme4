checkSlots <- function(x,y,...) {
    for (i in slotNames(x)) {
        cat(i,"\n")
        print(all.equal(slot(x,i),slot(y,i),...))
    }
}
