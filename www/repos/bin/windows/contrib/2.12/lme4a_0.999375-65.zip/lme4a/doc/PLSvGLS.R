###################################################
### chunk number 1: preliminaries
###################################################
#line 26 "C:/DOCUME~1/bates/LOCALS~1/Temp/RtmpRYt25h/R.INSTALL297339c/lme4a/inst/doc/PLSvGLS.Rnw"
options(width=65,digits=5)
#library(lme4)


