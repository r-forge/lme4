### R code from vignette source 'lme4-extras.Rnw'

###################################################
### code chunk number 1: prelim
###################################################
## stuff for making pretty PDFs -- **ignore** if running
##  interactively ...
if (require(knitr)) {
    ## require(highlight)
    knit_hooks$set(
                 fig=function(before, options, envir) {
                   if (before) {
                     par(bty="l",las=1)
                   } else { }
                 }
                 ## comment out printfun: not needed and provokes warnings from R CMD check
                 ## ,
                 ## from Yihui Xie: https://gist.github.com/1805862
                 ## printfun <- function(before, options, envir) {
                 ##   if (before) return()
                 ##   txt <- capture.output(dump(options$printfun, ''))
                 ##   ## reformat if tidy=TRUE
                 ##   if (options$tidy) txt = formatR::tidy.source(text = txt, output = FALSE)$text.tidy
                 ##   con = textConnection(txt)
                 ##   on.exit(close(con))
                 ##   out = capture.output({
                 ##     highlight::highlight(con, renderer = highlight::renderer_latex(document= FALSE),
                 ##                          showPrompts = options$prompt, size = options$size,show_line_numbers=TRUE)
                 ##   })
                 ##   paste(out, collapse = '\n')
                 ## }
                 )
## olddev <- options(device = function(...) {
##          .Call("R_GD_nullDevice", PACKAGE = "grDevices")
##        })
}
#library(ggplot2)
#theme_update(theme_bw())


###################################################
### code chunk number 2: splom_mcmc_def
###################################################
## modified from plotSplom
splom.mcmc <- function (mcmc, div = 1, log = FALSE, axes=FALSE,
                        base = 10, pch=".", contour=FALSE,
                        points = TRUE, ...)
{
  if (is.mcmc.list(mcmc))
    mcmc <- as.mcmc(mcmc)
  if (is.mcmc(mcmc))
    mcmc <- as.data.frame(mcmc)
  ellipsis <- as.list(substitute(list(...)))[-1]
  if (is.null(dim(mcmc)))
    stop("Argument 'mcmc' must contain more than one variable, ",
         "arranged in columns.")
  mcmc <- if (log)
    log(mcmc/div, base = base)
  else mcmc/div
  lp <- up <- function(...) {}  ## null panel function
  if (contour) {
    stop("not working yet")
    require(MASS)
    up <- function(x,y) {
      k <- kde2d(x,y)
      panel.contourplot(x=k$x,y=k$y,z=k$z,contour=TRUE,region=FALSE)
    }
  }
  if (points) {
    lp <- panel.splom
  }
  args <- c(list(mcmc,pch=pch,
                 diag.panel=diag.panel.splom,
                 lower.panel=lp,
                 upper.panel=up),list(...))
  if (!axes) {
    ## stop("not working yet")
    ## stub
    args <- c(args,list(pscale=0))
  }
  do.call(splom,args)
}


###################################################
### code chunk number 3: fitbasic
###################################################
library(lme4)
fm1 <- lmer(Reaction ~ Days + (Days|Subject), sleepstudy)
gm1 <- glmer(cbind(incidence, size - incidence) ~
             period + (1 | herd),
             data = cbpp, family = binomial)


###################################################
### code chunk number 4: fm1_getdevfun
###################################################
fm1Fun <- update(fm1,devFunOnly=TRUE)
fm1_thpar <- getME(fm1,"theta")


###################################################
### code chunk number 5: cvfuns
###################################################
Sv_to_Cv <- lme4:::Sv_to_Cv
Cv_to_Sv <- lme4:::Cv_to_Sv


###################################################
### code chunk number 6: fm1funS
###################################################
fm1FunS <- function(spar) {
    thpar <- Sv_to_Cv(c(spar,NA),s=fm1_spar[4])
    fm1Fun(thpar)
}


###################################################
### code chunk number 7: fm1_gethess
###################################################
library(numDeriv)
fm1_spar <- Cv_to_Sv(fm1_thpar,s=sigma(fm1))
all(abs(Sv_to_Cv(fm1_spar,s=fm1_spar[4])-fm1_thpar)<1e-6)
h <- hessian(fm1FunS,fm1_spar[-4])


###################################################
### code chunk number 8: fm1_varcov
###################################################
vcov_ran <- solve(h)


###################################################
### code chunk number 9: fm1prof
###################################################
pp <- profile(fm1)


###################################################
### code chunk number 10: profplotfuns
###################################################
as.data.frame.thpr <- function(x) {
    class(x) <- "data.frame"
    m <- as.matrix(x[,seq(ncol(x))-1]) ## omit .par
    x[[".focal"]] <- m[cbind(seq(nrow(x)),match(x$.par,names(x)))]
    x[[".par"]] <- factor(x[[".par"]],levels=unique(as.character(x[[".par"]]))) ## restore order
    x
}
profcmppanel <- function(fit,vcov_ran,spar) {
    nvpar <- length(getME(fit,"theta"))+1
    fixsd <- sqrt(diag(as.matrix(vcov(fit))))
    fixm <- fixef(fit)
    function (...) {
        panel.xyplot(...)
        i <- panel.number()
        if (i>nvpar) {
            i <- i-(nvpar)
            s <- 1/fixsd[i]
            ctr <- fixm[i]
        } else if (i<=(nvpar-1)) {
            s <- 1/sqrt(diag(vcov_ran))[i]
            ctr <- spar[i]
        }
        panel.abline(a=-ctr*s,b=s,col="red")
        panel.abline(v=ctr,col="gray")
        panel.abline(h=0,col="gray")
    }
}
xyplot(.zeta~.focal|.par,type="l",
       data=as.data.frame(pp),
       scale=list(x=list(relation="free")),
       as.table=TRUE,
       panel=profcmppanel(fm1,vcov_ran,fm1_spar))


###################################################
### code chunk number 11: fm1_profCI
###################################################
(ci_prof <- confint(pp))
c(fm1_spar,fixef(fm1))+
    1.96*outer(c(sqrt(diag(vcov_ran)),NA,sqrt(diag(as.matrix(vcov(fm1))))),
               c(-1,1))


###################################################
### code chunk number 12: lme4-extras.Rnw:235-236
###################################################
library(MCMCpack)


###################################################
### code chunk number 13: lme4-extras.Rnw:246-277
###################################################
## copy of VarCorr with extra bits -- perhaps eventually migrate to lme4 proper
## obsolete???
VC <- function(x, sigma, rdig, theta=getME(x,"theta"),
               format=c("std","varcovvec","sdcorvec"),
               vecfmt=FALSE)                         # <- 3 args from nlme
{
  format <- match.arg(format)
  if (is.null(cnms <- x@cnms))
    stop("VarCorr methods require reTrms, not just reModule")
  if(missing(sigma)) # "bug": fails via default 'sigma=sigma(x)'
    sigma <- lme4::sigma(x)  ## FIXME: do we need lme4:: ?
  nc <- sapply(cnms, length)	  # no. of columns per term
  m <- lme4:::mkVarCorr(sigma, cnms=cnms, nc=nc, theta = theta,
                             nms = {fl <- x@flist; names(fl)[attr(fl, "assign")]})
  attr(m,"useSc") <- as.logical(x@devcomp$dims["useSc"])
  if (format=="varcovvec") {
    v <- unlist(lapply(m,function(x) x[lower.tri(x,diag=TRUE)]))
    names(v) <- names(getME(x,"theta"))
    return(v)
  }
  if (format=="sdcorvec") {
    v <- unlist(lapply(m,function(x) {
      z <- attr(x,"correlation")
      diag(z) <- attr(x,"stddev")
      z[lower.tri(z,diag=TRUE)]}))
    names(v) <- names(getME(x,"theta"))
    return(v)
  }
  class(m) <- "VarCorr.merMod"
  m
}


###################################################
### code chunk number 14: lme4-extras.Rnw:280-284
###################################################
fm1_metropfun <- function(x) {
  ## getME(.,"lower")?
  if (any(x<fm1@lower)) -Inf else -fm1Fun(x)/2
}


###################################################
### code chunk number 15: fm1_mcmc
###################################################
fm1_mcmc_out <- MCMCmetrop1R(fm1_metropfun,fm1_thpar,seed=12345)
colnames(fm1_mcmc_out) <- names(fm1_thpar)


###################################################
### code chunk number 16: coda
###################################################
library(coda)


###################################################
### code chunk number 17: splom
###################################################
splom(fm1_mcmc_out)


###################################################
### code chunk number 18: traceplot
###################################################
xyplot(fm1_mcmc_out)


###################################################
### code chunk number 19: dplot
###################################################
densityplot(fm1_mcmc_out,layout=c(1,3))


###################################################
### code chunk number 20: interval
###################################################
HPDinterval(fm1_mcmc_out)


###################################################
### code chunk number 21: fm1_sdmat
###################################################
sdmat <- as.mcmc(t(apply(fm1_mcmc_out,1,
                         function(x) c(Cv_to_Sv(x,s=sigma(fm1))))))


###################################################
### code chunk number 22: fm1_HPD
###################################################
HPDinterval(sdmat)


###################################################
### code chunk number 23: lme4-extras.Rnw:326-327
###################################################
t(apply(sdmat,2,quantile,c(0.025,0.975)))


###################################################
### code chunk number 24: lme4-extras.Rnw:331-333
###################################################
qq <- t(apply(fm1_mcmc_out,2,quantile,c(0.025,0.975)))
apply(qq,2,function(x) VC(fm1,theta=x,format="sdcorvec"))


###################################################
### code chunk number 25: lme4-extras.Rnw:354-360
###################################################
gm1Fun <- update(gm1,devFunOnly=TRUE)
gm1_par <- c(getME(gm1,"theta"),fixef(gm1))
nt <- length(getME(gm1,"theta"))
gm1_metropfun <- function(x) {
  if (any(x[seq(nt)]<gm1@lower)) -Inf else -gm1Fun(x)/2
}


###################################################
### code chunk number 26: gm1_mcmc
###################################################
gm1_mcmc_out <- MCMCmetrop1R(gm1_metropfun,gm1_par)


###################################################
### code chunk number 27: gmplots
###################################################
colnames(gm1_mcmc_out) <- names(gm1_par)
xyplot(gm1_mcmc_out[,1:2])
splom(gm1_mcmc_out)
HPDinterval(gm1_mcmc_out)


###################################################
### code chunk number 28: lme4-extras.Rnw:382-443
###################################################
zipme <- function(cformula, zformula, cfamily=poisson,
                  data, maxitr=20, tol=1e-6, verbose=TRUE) {
  ##   y is the observation from the distribution:
  ##           P(Y=0)=p+(1-p)F(0,lambda)
  ##           P(Y=k)=(1-p)F(k,lambda).
  ##  zformula: formula for logistic regression on zero-inflation: LHS should be z~
  ##  cformula: formula for Poisson or NB regression. LHS should be: y~
  ##   maxitr  : maximum number of iterations
  ##   tol: convergence tolerance
  ##

  m<-nrow(data)
  rname <- as.character(cformula)[2]
  ## initialize z and probz (z=1 -> perfect state; probz is probability of 0 in imperfect state for poisson)

  z<-numeric(m)
  probz<-numeric(m)
  z[data[[rname]]==0]<- 1/(1+exp(-1))  ## starting value

  ## n.b. we are looking for [3] since zformula has a LHS
  randz <- length(grep("\\(.*\\|.*\\)",as.character(zformula)[3]))>0
  ## delta is used to gauge convergence. after initialization, it is the abs. difference between current z and new z.
  itr <- 1
  delta <- 2
  deltainfo <- numeric(maxitr)
  while(delta>tol & itr <= maxitr){
    if (verbose) cat("itr:",itr,"\n")
    ## make (update) working data frame
    bydataw <- data.frame(z=z,data)
    ##
    ## Maximization 1: logistic
    old.z<-z
    if (randz) {
      uu <- glmer(zformula, family=binomial, data=bydataw)
    } else {
      uu <- glm(zformula, family=binomial, data=bydataw)
    }
    ## save current logistic model output
    u <- fitted(uu)
    ##
    ## Maximization 2: poisson/NB loglinear with weights
    vv <- glmer(cformula, family=cfamily, weights=(1-z), data=bydataw)
    ## save Poisson model output
    v <- fitted(vv)
    ##
    ## Expectation: used to update z with conditional expectation;only need to update at y=0.
    zdat <- data[[rname]]==0
    z[zdat] <- u[zdat]/( u[zdat]+(1-u[zdat])*exp(-v[zdat]))
    new.z<-z
    ## updated convergence indicator
    delta<-max(abs(old.z-new.z))
    ## save delta for this iteration; to be output
    deltainfo[itr] <- delta
    itr <- itr+1
  }
  L <- list("zfit"=uu, "cfit"=vv, itr=itr, deltainfo=deltainfo, z=z)
  ##    uu.binom : output object of logistic regression;
  ##    vv.flm   : output object of poisson regression
  class(L) <- "zipme"
  L
}


###################################################
### code chunk number 29: lme4-extras.Rnw:447-448
###################################################
## options(device=olddev$device)


