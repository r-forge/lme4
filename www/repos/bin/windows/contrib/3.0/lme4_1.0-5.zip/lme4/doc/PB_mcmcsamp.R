### R code from vignette source 'PB_mcmcsamp.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: PB_mcmcsamp.Rnw:9-41
###################################################
get_pvars <- function(object) {
    v <- c(unlist(VarCorr(object)),units=sigma(object)^2)
    names(v) <- c(names(getME(object,"theta")),"units")
    v
}
get_mcvars <- function(object,mcmc,mcmcglmm=NULL) {
    ## get pvars, convert to 1-row data frame
    pvars <- as.data.frame(rbind(get_pvars(object)))
    ## get mcmc vars, drop fixed effects, rename
    nfix <- length(fixef(object))
    m0 <- as.data.frame(mcmc,type="varcov")[,-(1:nfix)]
    mmvars <- setNames(m0,names(pvars))
    L <- list(fitted=pvars,mcmc=mmvars)
    if (!is.null(mcmcglmm)) {
        m1 <- as.data.frame(mcmcglmm$VCV)
        ## re-arrange column names to match lmer
        regexstr <-
            "([[:alpha:]_\\(\\)]+)\\.([[:alpha:]_\\(\\)]+)"
        names(m1) <- gsub(regexstr,"\\2.\\1",names(m1))
        f1 <- rbind(colMeans(m1))
        ## combine mcmc and lmer results
        L$mcmc <- rbind(data.frame(method="mcmcsamp",
                                   step=seq(nrow(L$mcmc)),
                                   L$mcmc,check.names=FALSE),
                        data.frame(method="MCMCglmm",
                                   step=seq(nrow(m1)),m1,check.names=FALSE))
        L$fitted <- rbind(data.frame(method="mcmcsamp",
                                     L$fitted,check.names=FALSE),
                          data.frame(method="MCMCglmm",f1,check.names=FALSE))
    }
    L
}


###################################################
### code chunk number 2: PB_mcmcsamp.Rnw:45-59
###################################################
set.seed(666)
sims <- function(I, J, sigmab0, sigmaw0){
    Mu <- rnorm(I, mean=0, sd=sigmab0)
    y <- c(sapply(Mu, function(mu) rnorm(J, mu, sigmaw0)))
    data.frame(y=y, group=gl(I,J))
}
I <- 4 # number of groups
J <- 50 # number of repeats per group
sigmab0 <- sqrt(2) # between standard deviation
sigmaw0 <- sqrt(3) # within standard deviation
##Only 4 groups with variance = 2
dat.sim <- sims(I, J, sigmab0, sigmaw0)
library(lme4)
mod <- lmer(y ~1 + (1|group), dat.sim)


###################################################
### code chunk number 3: PB_mcmcsamp.Rnw:61-69 (eval = FALSE)
###################################################
## nsim <- 1e4
## ## library(lme4.0)
## ## mod2 <- lmer(y ~1 + (1|group), dat.sim)
## ## set.seed(101)
## ## mcmcsamp_t1 <- system.time(mcmcsampdat1 <- mcmcsamp(mod2, n=nsim))
## ## save("mcmcsampdat1","mcmcsamp_t1",file="mcmcsampdat.RData")
## load("mcmcsampdat.RData")
## v1 <- get_mcvars(mod2,mcmcsampdat1)


###################################################
### code chunk number 4: PB_mcmcsamp.Rnw:72-80 (eval = FALSE)
###################################################
## Vpop2=as.numeric(nsum)
## for (i in 1:nsum) {
##     dat2<-simulate(mod)
##     model2<-refit(mod, dat2)
##     Vpop2[i]=VarCorr( model2)$group[1]
## }
## den <- data.frame(y = c(v1$mcmc[,1], Vpop2 ),
##              met = rep(c("mcmcsamp","parametric boot"), each=nsum) )


###################################################
### code chunk number 5: PB_mcmcsamp.Rnw:83-91 (eval = FALSE)
###################################################
## library(lattice)
## densityplot(~ y, data=den, groups = met, xlim = c(-1,10),
##             main="Simulated data - between groups (n=4) variance = 2",
##             plot.points = TRUE, xlab = "VAR(group)", auto.key =
##             list(space = "right"))
## trellis.focus("panel", 1, 1, highlight = FALSE)
## panel.abline(v = VarCorr(mod)$group[1] )
## trellis.unfocus()


###################################################
### code chunk number 6: PB_mcmcsamp.Rnw:104-106 (eval = FALSE)
###################################################
## calcium <- read.table("calcium.txt",header=TRUE)
## lmer(Calcium~1+(1|Plant/Leaf),data=calcium)


