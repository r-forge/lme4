###################################################
### chunk number 1: preliminaries
###################################################
#line 27 "C:/Users/bates/AppData/Local/Temp/RtmpkPy7zb/R.INSTALL1ba9353c/lme4a/inst/doc/Theory.Rnw"
options(width=65,digits=5)
#library(lme4)


