###################################################
### chunk number 1: preliminaries
###################################################
#line 27 "d:/RCompile/CRANguest/R-release/lme4a/inst/doc/Theory.Rnw"
options(width=65,digits=5)
#library(lme4)


