###################################################
### chunk number 1: preliminaries
###################################################
#line 26 "d:/RCompile/CRANguest/R-release/lme4a/inst/doc/PLSvGLS.Rnw"
options(width=65,digits=5)
#library(lme4)


